from django.apps import AppConfig


class BookInfoConfig(AppConfig):
    name = 'book_info'
